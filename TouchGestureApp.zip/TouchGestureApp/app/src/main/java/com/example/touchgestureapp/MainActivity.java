package com.example.touchgestureapp;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.hardware.display.DisplayManager;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Bundle;
import android.view.MotionEvent;
import android.widget.Button;
import android.widget.TextView;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import okhttp3.*;
import android.net.Uri;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private Button startGestureButton;
    private TextView touchCoordinates;
    private TextView statusTextView;
    private TextView promptTextView;

    private List<float[]> touchCoordinatesList = new ArrayList<>();
    private OkHttpClient client = new OkHttpClient();

    // To track the start of gesture recording
    private boolean isRecordingGesture = false;

    private MediaProjectionManager mediaProjectionManager;
    private MediaProjection mediaProjection;

    // Define an ActivityResultLauncher for screen capture permission
    private ActivityResultLauncher<Intent> screenCaptureLauncher =
            registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
                if (result.getResultCode() == Activity.RESULT_OK) {
                    // User granted permission to capture the screen
                    Intent data = result.getData();
                    mediaProjection = mediaProjectionManager.getMediaProjection(result.getResultCode(), data);
                    // Now you can begin capturing the screen (this part needs additional logic)
                    statusTextView.setText("Screen capture started.");
                } else {
                    // Permission denied
                    statusTextView.setText("Screen capture permission denied.");
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize UI elements
        startGestureButton = findViewById(R.id.startGestureButton);
        touchCoordinates = findViewById(R.id.touchCoordinates);
        statusTextView = findViewById(R.id.statusTextView);
        promptTextView = findViewById(R.id.promptTextView);

        // Set button click listener
        startGestureButton.setOnClickListener(v -> startGestureRecording());

        // Initialize MediaProjectionManager
        mediaProjectionManager = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
    }

    // Capture touch events and store coordinates
    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (isRecordingGesture) {
            // Capture touch coordinates
            float x = event.getX();
            float y = event.getY();

            // Store coordinates in the list
            touchCoordinatesList.add(new float[]{x, y});

            // Optionally, update status with the latest coordinates
            touchCoordinates.setText("Touch Coordinates: (" + x + ", " + y + ")");
        }
        return super.onTouchEvent(event);
    }

    // Start gesture recording when button is clicked
    private void startGestureRecording() {
        // Disable the start button
        startGestureButton.setEnabled(false);
        statusTextView.setText("Recording gesture...");
        touchCoordinatesList.clear();
        // Show prompt
        promptTextView.setVisibility(TextView.VISIBLE);

        // Start recording touch events
        isRecordingGesture = true;

        // Wait for 5 seconds to record gesture
        new Thread(() -> {
            try {
                Thread.sleep(5000);  // Record gesture for 5 seconds
                sendCoordinatesToServer(touchCoordinatesList);  // Send captured coordinates to Flask server
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }).start();
    }

    // Send the touch coordinates to Flask server for gesture recognition
    private void sendCoordinatesToServer(List<float[]> coordinates) {
        // Manually build the JSON string
        StringBuilder jsonCoordinates = new StringBuilder("[");

        for (int i = 0; i < coordinates.size(); i++) {
            float[] point = coordinates.get(i);
            jsonCoordinates.append("[")
                    .append(point[0]).append(", ")
                    .append(point[1]).append("]");

            if (i < coordinates.size() - 1) {
                jsonCoordinates.append(", ");
            }
        }
        jsonCoordinates.append("]");

        // Prepare HTTP request
        RequestBody body = RequestBody.create(
                jsonCoordinates.toString(), MediaType.parse("application/json; charset=utf-8"));
        Request request = new Request.Builder()
                .url("http://192.168.1.7:5000/predict-gesture") // Replace with your Flask server's IP
                .post(body)
                .build();

        // Execute the HTTP request
        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                e.printStackTrace();  // Print the error for debugging
                runOnUiThread(() -> {
                    statusTextView.setText("Error occurred while sending data: " + e.getMessage());
                    startGestureButton.setEnabled(true);
                    promptTextView.setVisibility(TextView.GONE);
                    isRecordingGesture = false;
                });
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (response.isSuccessful()) {
                    // Handle the response from the server
                    String responseBody = response.body().string();
                    runOnUiThread(() -> {
                        statusTextView.setText("Gesture recorded: " + responseBody);
                        startGestureButton.setEnabled(true);
                        promptTextView.setVisibility(TextView.GONE);
                        isRecordingGesture = false;

                        // Call the appropriate method based on the response gesture
                        if ("L".equals(responseBody)) {
                            openCalculator();
                        } else if ("S".equals(responseBody)) {
                            takeScreenshot();
                        } else if ("star".equals(responseBody)) {
                            openImageFromGallery();
                        }
                    });
                } else {
                    runOnUiThread(() -> {
                        statusTextView.setText("Failed to recognize gesture.");
                        startGestureButton.setEnabled(true);
                        promptTextView.setVisibility(TextView.GONE);
                        isRecordingGesture = false;
                    });
                }
            }
        });
    }

    // Method to open the calculator app
    private void openCalculator() {
        Intent intent = new Intent(Intent.ACTION_MAIN);
        intent.addCategory(Intent.CATEGORY_APP_CALCULATOR);
        startActivity(intent);
    }

    // Method to take a screenshot (this is just an example, you'd need permissions for this)
    private void takeScreenshot() {
        Intent captureIntent = mediaProjectionManager.createScreenCaptureIntent();
        screenCaptureLauncher.launch(captureIntent);  // Launch using the ActivityResultLauncher
    }

    // Method to open multiple apps (for the "Star" gesture)
    private void openImageFromGallery() {
        // Define the URI for the image (replace with your image's URI from the gallery)
        Uri imageUri = Uri.parse("content://media/external/images/media/12345");  // Replace with the actual image URI

        // Create an Intent to view the image
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setDataAndType(imageUri, "image/*");  // Set MIME type for image
        startActivity(intent);  // Start the activity to open the image
    }
}
