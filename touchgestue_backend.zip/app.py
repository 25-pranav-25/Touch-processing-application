from flask import Flask, jsonify, render_template, request
import time
import pyautogui
import torch
import torch.nn as nn
import subprocess
from torchvision import models, transforms
import numpy as np
from PIL import Image, ImageDraw

# Flask application setup
app = Flask(__name__)

# Define the GestureClassifier class (same as during training)
class GestureClassifier(nn.Module):
    def __init__(self, num_classes):
        super(GestureClassifier, self).__init__()
        self.backbone = models.resnet18(weights=models.ResNet18_Weights.DEFAULT)

        # Modify the first conv layer to accept 1-channel input
        self.backbone.conv1 = nn.Conv2d(
            in_channels=1,  # Grayscale has 1 channel
            out_channels=self.backbone.conv1.out_channels,
            kernel_size=self.backbone.conv1.kernel_size,
            stride=self.backbone.conv1.stride,
            padding=self.backbone.conv1.padding,
            bias=self.backbone.conv1.bias is not None
        )

        # Modify the final fully connected layer for the number of gestures
        self.backbone.fc = nn.Linear(self.backbone.fc.in_features, num_classes)

    def forward(self, x):
        return self.backbone(x)

# Path to the saved model
model_save_path = r"C:\Users\dodo2\Downloads\touch_images\gesture_classifier.pth"

# Initialize and load the model
num_classes = 3  # Update this based on the number of gesture classes
model = GestureClassifier(num_classes=num_classes)
model.load_state_dict(torch.load(model_save_path, map_location=torch.device('cpu')))
model.eval()

# Transformation pipeline for model input
transform = transforms.Compose([
    transforms.Grayscale(num_output_channels=1),
    transforms.Resize((256, 256)),
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.5], std=[0.5])
])

# Route to display the HTML page with the button
@app.route('/')
def index():
    return render_template('index.html')

def perform_action(gesture):
    if gesture == "L":
        open_calculator()
        return "Opened Calculator"
    elif gesture == "S":
        take_screenshot()
        return "Screenshot taken"
    elif gesture == "star":
        open_multiple_apps()
        return "Multiple applications opened"
    else:
        return "Unknown gesture"

# Action functions for each gesture
def open_calculator():
    subprocess.run("calc", shell=True)

def take_screenshot():
    screenshot = pyautogui.screenshot()
    screenshot.save("screenshot.png")
    print("Screenshot saved as screenshot.png")

def open_multiple_apps():
    subprocess.run("start notepad", shell=True)  # Open Notepad
    subprocess.run("start https://www.youtube.com", shell=True)  # Open YouTube
    subprocess.run("start calc", shell=True)  # Open Calculator

# Route to start recording the gesture by tracking the cursor path
@app.route('/start-gesture', methods=['GET'])
def start_gesture():
    duration = 5  # Duration to track the cursor in seconds
    gesture_image = trace_cursor_path(duration)

    # Predict the gesture using the trained model
    predicted_gesture = predict_image(gesture_image)
    action_response = perform_action(predicted_gesture)
    # Return JSON response with the predicted gesture
    return jsonify({"status": "Gesture recorded", "message": predicted_gesture, "Performed Action": action_response}), 200


# Route to handle received touch coordinates and generate image
@app.route('/predict-gesture', methods=['POST'])
def predict_gesture():
    # Get the touch coordinates data from the Android app
    data = request.get_json()

    # Since data is a list of coordinates, we don't need to access 'coordinates'
    touch_coordinates = data

    # Generate the 256x256 image with touch coordinates
    image = generate_gesture_image(touch_coordinates)

    # Save the image temporarily (for debugging or further processing)
    image.save("gesture_image.png")

    # Predict the gesture using the trained model
    predicted_gesture = predict_image(image)

    # Return a success response with the predicted gesture
    return jsonify({"status": "Gesture recognized", "gesture": predicted_gesture}), 200

# Function to generate a 256x256 image with continuous lines between touch coordinates
def generate_gesture_image(touch_coordinates):
    # Create a blank black image (256x256 pixels)
    image = Image.new("1", (256, 256), 0)  # "1" means 1-bit color (black and white)
    draw = ImageDraw.Draw(image)

    # Find the maximum values for x and y (this is for scaling the coordinates)
    max_x = max([coord[0] for coord in touch_coordinates]) if touch_coordinates else 0
    max_y = max([coord[1] for coord in touch_coordinates]) if touch_coordinates else 0

    # Find the scale factor to normalize coordinates to fit within the 256x256 canvas
    scale_x = 255 / max_x if max_x > 0 else 1
    scale_y = 255 / max_y if max_y > 0 else 1

    # Normalize and plot each touch point as a continuous line
    for i in range(1, len(touch_coordinates)):
        # Normalize coordinates to fit into the 256x256 image
        x1, y1 = touch_coordinates[i - 1]
        x2, y2 = touch_coordinates[i]

        # Scale the coordinates
        scaled_x1 = int(x1 * scale_x)
        scaled_y1 = int(y1 * scale_y)
        scaled_x2 = int(x2 * scale_x)
        scaled_y2 = int(y2 * scale_y)

        # Ensure coordinates are within the 0-255 range
        if 0 <= scaled_x1 < 256 and 0 <= scaled_y1 < 256 and 0 <= scaled_x2 < 256 and 0 <= scaled_y2 < 256:
            draw.line([scaled_x1, scaled_y1, scaled_x2, scaled_y2], fill=1, width=3)  # Draw line between points

    return image

# Function to trace the cursor path (for laptop gesture recording)
def trace_cursor_path(duration, interval=0.01):
    # Get the size of the screen
    screen_width, screen_height = pyautogui.size()

    # Create a blank black image
    image = Image.new("L", (screen_width, screen_height), 0)
    draw = ImageDraw.Draw(image)

    # Track cursor positions and draw lines
    previous_position = pyautogui.position()
    start_time = time.time()

    while time.time() - start_time < duration:
        current_position = pyautogui.position()

        # Draw a line from the previous position to the current position
        draw.line([previous_position, current_position], fill=255, width=3)

        # Update the previous position
        previous_position = current_position

        # Wait for the specified interval before capturing the next position
        time.sleep(interval)

    # Resize image for model input (optional)
    image = image.resize((256, 256))
    return image

# Function to predict the gesture using the trained model
def predict_image(image):
    # Apply transformations to the image
    input_tensor = transform(image).unsqueeze(0)  # Add batch dimension

    # Predict the gesture
    with torch.no_grad():
        output = model(input_tensor)
        predicted_class = output.argmax(dim=1).item()

    # Map the class index to a gesture label (define the mapping based on your dataset)
    gesture_mapping = {
        0: "L",
        1: "S",
        2: "star"
    }

    return gesture_mapping.get(predicted_class, "Unknown Gesture")

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
